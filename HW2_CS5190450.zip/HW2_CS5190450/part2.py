from sklearn.cluster import KMeans
import sys
import matplotlib.pyplot as plt
# Taking dimension = 5
inputfile = sys.argv[1]
dimension = sys.argv[2]
output = sys.argv[3]

lst = []

file = open(inputfile,"r")

for lines in file:
    # if(lines[-1]=="\n"):
    #     lines = lines[:-1]
    l = list(map(float,lines.split()))
    lst.append(l)
    # x1.append(l[0])
    # x2.append(l[1])
    # x3.append(l[2])
    # x4.append(l[3])
    # x5.append(l[4])
file.close()
# l = list(zip(x1,x2,x3,x4,x5))
ans = []

for k in range(1,16):
    clusters = KMeans(n_clusters=k)
    clusters.fit(lst)
    ans.append(clusters.inertia_)


plt.plot(range(1,16), ans, marker = "o")
plt.xlabel("K values")
plt.ylabel("Inertia(variation within cluster)")
plt.title("Elbow-plot")
plt.savefig(output)