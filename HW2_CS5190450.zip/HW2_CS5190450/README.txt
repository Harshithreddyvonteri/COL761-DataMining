Contributions:
Vonteri Harshith Reddy - 2019CS50450 - 33.33%
Chapala Sriram Varma - 2019CS50426 - 33.33%
Somisetty Harsha Vardhan - 2020CS10390 - 33.33%

Report.pdf contains plots,detailed analysis and results
Q1:
conv-graph.py: takes dataset and algorithm as arguments and formats the dataset
part1.py: runs fsg,gSpan,gaston on 5 support values and saves the plot
To run: sh part1.sh <graph_dataset0>

Q2:
part2.py: takes dataset, dimension and output filename as input and plots the elbow-curve
To run: sh elbow_plot.sh <dataset> <dimension> q3_<dimension>_<RollNo>.png

Modules to load: python, sckit-learn, matplotlib