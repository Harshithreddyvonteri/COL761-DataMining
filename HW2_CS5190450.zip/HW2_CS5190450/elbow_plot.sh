module load pythonpackages/3.6.0/scikit-learn/0.21.2/gnu
module load compiler/python/3.6.0/ucs4/gnu/447
module load pythonpackages/3.6.0/matplotlib/3.0.2/gnu
python3 part2.py $1 $2 $3
